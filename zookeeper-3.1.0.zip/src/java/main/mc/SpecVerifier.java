package mc;

public abstract class SpecVerifier {
    
    public abstract boolean verify();

}
