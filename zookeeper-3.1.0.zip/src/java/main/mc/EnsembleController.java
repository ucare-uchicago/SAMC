package mc;

public interface EnsembleController {
    
    public void startNode(int id);
    public void stopNode(int id);
    public void startEnsemble();
    public void stopEnsemble();

}
