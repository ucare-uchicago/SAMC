package mc.transition;


abstract public class NodeOperationTransition extends Transition {

    public int id;
    
    public int getId() {
        return id;
    }
    
}
