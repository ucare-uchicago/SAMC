package mc.zookeeper.quorum;

import mc.PacketReleaseCallback;

public interface QuorumBroadcastCallback extends PacketReleaseCallback {

}
