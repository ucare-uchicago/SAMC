package mc;

public class AbstractLocalState {
    
    public int getStateValue() {
        return hashCode();
    }

}
